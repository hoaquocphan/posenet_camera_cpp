1/ run command to check required software and compare with file environment_conversion.txt:

pip freeze

2/ run command  for help

python convert.py --hint True  